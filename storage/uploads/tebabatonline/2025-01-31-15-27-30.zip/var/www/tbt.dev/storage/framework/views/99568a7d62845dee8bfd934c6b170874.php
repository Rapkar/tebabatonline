<?php $__env->startSection('content'); ?>
<div class="container">
  <table class="table table-striped table-bordered table-rtl">
    <thead>
      <tr>
        <th>نام پست</th>
        <th>وضعیت</th>
        <th>تعداد بازدید</th>
        <th>عملیات</th>
      </tr>
    </thead>
    <tbody>
      <!-- Users list goes here -->

      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($product->name); ?></td>
        <td>
          <span class="status <?php echo e($product->status == 1 ? 'green' : 'red'); ?> "> </span>
        </td>
        <td><?php echo e($product->count); ?></td>
        <td>
          <a href="<?php echo e(route('editproduct', $product->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="ویرایش"> ویرایش </a>
          <a href="<?php echo e(route('deleteproduct', $product->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="حذف"> حذف </a>
          <a   href="<?php echo e(route('products', $product->slug)); ?>" target="_new" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="نمایش پست"> نمایش </a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- More users list goes here -->
    </tbody>
  </table>
  <?php echo $__env->make('admin_panel.layouts.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/tbt.dev/resources/views/admin_panel/products/list-product.blade.php ENDPATH**/ ?>