<nav aria-label="Page navigation example">
  <ul class="pagination">
    
    <?php if($items->onFirstPage()): ?>
      <li class="page-item disabled"><span class="page-link"><?php echo e(__("admin.Previous")); ?></span></li>
    <?php else: ?>
      <li class="page-item"><a class="page-link" href="<?php echo e($items->previousPageUrl()); ?>"><?php echo e(__("admin.Previous")); ?></a></li>
    <?php endif; ?>

    
    <?php $__currentLoopData = $items->links()->elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <?php if(is_string($element)): ?>
        <li class="page-item disabled"><span class="page-link"><?php echo e($element); ?></span></li>
      <?php endif; ?>

      
      <?php if(is_array($element)): ?>
        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($page == $items->currentPage()): ?>
            <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
          <?php else: ?>
            <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($items->hasMorePages()): ?>
      <li class="page-item"><a class="page-link" href="<?php echo e($items->nextPageUrl()); ?>"><?php echo e(__("admin.Next")); ?></a></li>
    <?php else: ?>
      <li class="page-item disabled"><span class="page-link"><?php echo e(__("admin.Next")); ?></span></li>
    <?php endif; ?>
  </ul>
</nav>
<?php /**PATH /var/www/tbt.dev/resources/views/admin_panel/layouts/pagination.blade.php ENDPATH**/ ?>