<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h1>افزودن پست جدید</h1>
            <form action="<?php echo e(route('updatepost',$post->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-4">
                    <label for="title">تیتر:</label>
                    <input type="text" value="  <?php echo e($post->name); ?>" name="name" class="form-control" required>
                </div>
                <div class="form-group mb-4">
                    <label for="body">محتوا:</label>
                    <textarea id="postcontent" name="content"><?php echo e($post->content); ?></textarea>
                </div>
                <div class="form-group mb-4">
                    <label for="body">خلاصه:</label>
                    <textarea rows="6" id="expert" name="expert" class="w-100"><?php echo e($post->expert); ?></textarea>
                </div>
                <div class="form-group mb-4 col-lg-6">
                    <label for="body">دسته بندی:</label>
                    <select multiple id="category" name="category[]">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(in_array($category->id, $ids) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mb-4 col-lg-6">
                    <label for="body">آدرس لینک:</label>
                    website.com/<b>post1</b><br>

                    <input require type="text" class="form-control" value="<?php echo e($post->slug); ?>" placeholder="آدرس پست من " name="slug" />

                </div>
                <div class="form-group mb-4">
                    <label for="body">تصویر شاخص:</label>
                    <div class="dz-preview dz-file-preview">
                        <div class="dz-image">
                            <img data-dz-thumbnail src="<?php echo e(url($post->image)); ?>" />
                        </div>
                    </div>
                    <div  class="dropzone" id="postimg">
                        <input type="hidden" value="<?php echo e($post->image); ?>" id="image" name="image">
                    </div>
                </div>
                <div class="form-group mb-4">
                    <label for="body">وضعیت:</label>
                    <select id="status" name="status">
                        <option <?php echo e($post->status == 0 ? 'selected' : ''); ?> value="0">عدم انتشار</option>
                        <option <?php echo e($post->status == 1 ? 'selected' : ''); ?> value="1">انتشار</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">اصلاح پست</button>

                </div>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/tbt.dev/resources/views/admin_panel/posts/edit-post.blade.php ENDPATH**/ ?>