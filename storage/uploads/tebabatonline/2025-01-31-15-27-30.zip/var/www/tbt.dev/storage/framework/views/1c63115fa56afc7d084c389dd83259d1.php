<?php $__env->startSection('content'); ?>
<div class="container">
  <form class="filter" method="post" action="<?php echo e(route('posts.filter')); ?>">
    <?php echo csrf_field(); ?>
    <fieldset class="row mb-5"> <legend>فیلتر جستجو</legend>
      <div class="form-group col-lg-2">
        <label for="exampleInputEmail1"> <?php echo e(__('admin.by data')); ?></label>
        <input type="date" class="form-control" id="date" name="date" aria-describedby="date" placeholder="Enter email">
        <small id="emailHelp" class="form-text text-muted"> بر اساس تاریخ ثبت جستجو کنید.</small>
      </div>
      <div class="form-group col-lg-4">
        <label for="exampleInputEmail1"> <?php echo e(__('admin.by name')); ?></label>
        <input type="text" class="form-control" id="name" aria-describedby="name" name="name" placeholder="نام پست را وارد کنید.">
        <small id="emailHelp" class="form-text text-muted">براساس نام پست جستجو کنید.</small>
      </div>
      <div class="form-group col-lg-3">
        <label for="exampleInputEmail1"> <?php echo e(__('admin.by status')); ?></label>
        <select name="status" class="custom-select form-control   mb-3">
          <option disabled>انتخاب وضعیت انتشار</option>
          <option value="2">همه</option>
          <option value="1">انتشار</option>
          <option value="0">عدم انتشار</option>
        </select>
        <small id="emailHelp" class="form-text text-muted">بر اساس وضعیت انتشار یا عدم انتشار جستجو کنید.</small>
      </div>
      <div class="form-group col-lg-3">
        <label for="exampleInputEmail1"> <?php echo e(__('admin.show result')); ?></label>
        <button type="submit" class="form-control btn btn-primary"><?php echo e(__('admin.search')); ?></button>
        <small id="emailHelp" class="form-text text-muted">با کلیک روی این گزینه فیلتر مورد نظر اعمل میشود</small>
      </div>
     
    </fieldset>

  </form>
  <hr>
  <table class="table table-striped table-bordered table-rtl">
    
    <thead>
      <tr>
        <th>نام پست</th>
        <th>وضعیت انتشار</th>
        <th>تعداد بازدید</th>
        <th>تاریخ</th>
        <th>عملیات</th>
      </tr>
    </thead>
    <tbody>
      <!-- Users list goes here -->

      <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($post->name); ?></td>
        <td>
          <span class="status <?php echo e($post->status == 1 ? 'green' : 'red'); ?> "> </span>
        </td>
        <td><?php 
            echo e(Verta::parse($post->created_at)->format('Y/m/d H:i:s')); 
        ?></td>
        <td><?php echo e($post->count); ?></td>
        <td>
          <a href="<?php echo e(route('editpost', $post->id)); ?>" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="ویرایش"> ویرایش </a>
          <a href="<?php echo e(route('delete', $post->id)); ?>" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="حذف"> حذف </a>
          <a href="<?php echo e(route('articles', $post->slug)); ?>" target="_new" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="top" title="نمایش پست"> نمایش </a>
        </td>
      </tr>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <!-- More users list goes here -->
    </tbody>
  </table>
  <?php echo $__env->make('admin_panel.layouts.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/tbt.dev/resources/views/admin_panel/posts/list-post.blade.php ENDPATH**/ ?>